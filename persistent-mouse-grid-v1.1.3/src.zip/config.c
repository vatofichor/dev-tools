/*
# Copyright (c) 2026:
# vatofichor - Sebastian Mass     [>_<]
# & Assisted By Gemini Antigravity /|\
*/

#include "config.h"
#include "vendor/cJSON/cJSON.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <process.h>

AppConfig g_config = {0};

// Helper to copy strings safely
static void SafeStringCopy(char* dest, size_t destSize, const char* src) {
    if (src && dest && destSize > 0) {
        strncpy(dest, src, destSize - 1);
        dest[destSize - 1] = '\0';
    }
}

// Reads entire file into a null-terminated buffer (Max 1MB limit for safety)
static char* ReadFileContents(const char* filepath) {
    FILE* file = fopen(filepath, "rb");
    if (!file) return NULL;

    fseek(file, 0, SEEK_END);
    long length = ftell(file);
    fseek(file, 0, SEEK_SET);

    // Security Integrity: Reject extraordinarily large files to prevent OOM
    if (length <= 0 || length > 1024 * 1024) {
        fclose(file);
        return NULL;
    }

    char* buffer = (char*)malloc(length + 1);
    if (buffer) {
        fread(buffer, 1, length, file);
        buffer[length] = '\0';
    }
    
    fclose(file);
    return buffer;
}

bool LoadConfig(const char* filepath) {
    char* jsonStr = ReadFileContents(filepath);
    if (!jsonStr) {
        // Provide defaults if file not found
        g_config.grid.primary_rows = 3;
        g_config.grid.primary_cols = 3;
        g_config.grid.subgrid_rows = 3;
        g_config.grid.subgrid_cols = 3;
        SafeStringCopy(g_config.styling.primary_line_color, sizeof(g_config.styling.primary_line_color), "#FF0055");
        g_config.styling.primary_line_opacity = 0.45f;
        g_config.styling.primary_line_thickness = 2;
        SafeStringCopy(g_config.styling.subgrid_line_color, sizeof(g_config.styling.subgrid_line_color), "#B0B0B0");
        g_config.styling.subgrid_line_opacity = 0.25f;
        g_config.styling.subgrid_line_thickness = 1;
        SafeStringCopy(g_config.styling.font_family, sizeof(g_config.styling.font_family), "Segoe UI");
        g_config.styling.font_size = 14;
        SafeStringCopy(g_config.styling.text_color, sizeof(g_config.styling.text_color), "#FFFFFF");
        SafeStringCopy(g_config.styling.badge_bg_color, sizeof(g_config.styling.badge_bg_color), "#000000");
        g_config.styling.badge_bg_opacity = 0.5f;
        SafeStringCopy(g_config.behavior.hotkey_toggle, sizeof(g_config.behavior.hotkey_toggle), "Ctrl+Shift+G");
        SafeStringCopy(g_config.behavior.target_display, sizeof(g_config.behavior.target_display), "all");
        g_config.behavior.target_mode = TARGET_DISPLAY_ALL;
        g_config.behavior.target_index = 0;
        return false;
    }

    cJSON* root = cJSON_Parse(jsonStr);
    free(jsonStr);
    
    if (!root) return false;

    // Parse Grid
    cJSON* grid = cJSON_GetObjectItemCaseSensitive(root, "grid");
    if (grid) {
        cJSON* prow = cJSON_GetObjectItemCaseSensitive(grid, "primary_rows");
        if (cJSON_IsNumber(prow)) g_config.grid.primary_rows = prow->valueint;
        cJSON* pcol = cJSON_GetObjectItemCaseSensitive(grid, "primary_cols");
        if (cJSON_IsNumber(pcol)) g_config.grid.primary_cols = pcol->valueint;
        cJSON* srow = cJSON_GetObjectItemCaseSensitive(grid, "subgrid_rows");
        if (cJSON_IsNumber(srow)) g_config.grid.subgrid_rows = srow->valueint;
        cJSON* scol = cJSON_GetObjectItemCaseSensitive(grid, "subgrid_cols");
        if (cJSON_IsNumber(scol)) g_config.grid.subgrid_cols = scol->valueint;
    }

    // Parse Styling
    cJSON* styling = cJSON_GetObjectItemCaseSensitive(root, "styling");
    if (styling) {
        cJSON* plc = cJSON_GetObjectItemCaseSensitive(styling, "primary_line_color");
        if (cJSON_IsString(plc)) SafeStringCopy(g_config.styling.primary_line_color, sizeof(g_config.styling.primary_line_color), plc->valuestring);
        cJSON* plo = cJSON_GetObjectItemCaseSensitive(styling, "primary_line_opacity");
        if (cJSON_IsNumber(plo)) g_config.styling.primary_line_opacity = (float)plo->valuedouble;
        cJSON* plt = cJSON_GetObjectItemCaseSensitive(styling, "primary_line_thickness");
        if (cJSON_IsNumber(plt)) g_config.styling.primary_line_thickness = plt->valueint;

        cJSON* slc = cJSON_GetObjectItemCaseSensitive(styling, "subgrid_line_color");
        if (cJSON_IsString(slc)) SafeStringCopy(g_config.styling.subgrid_line_color, sizeof(g_config.styling.subgrid_line_color), slc->valuestring);
        cJSON* slo = cJSON_GetObjectItemCaseSensitive(styling, "subgrid_line_opacity");
        if (cJSON_IsNumber(slo)) g_config.styling.subgrid_line_opacity = (float)slo->valuedouble;
        cJSON* slt = cJSON_GetObjectItemCaseSensitive(styling, "subgrid_line_thickness");
        if (cJSON_IsNumber(slt)) g_config.styling.subgrid_line_thickness = slt->valueint;

        cJSON* ff = cJSON_GetObjectItemCaseSensitive(styling, "font_family");
        if (cJSON_IsString(ff)) SafeStringCopy(g_config.styling.font_family, sizeof(g_config.styling.font_family), ff->valuestring);
        cJSON* fs = cJSON_GetObjectItemCaseSensitive(styling, "font_size");
        if (cJSON_IsNumber(fs)) g_config.styling.font_size = fs->valueint;
        
        cJSON* tc = cJSON_GetObjectItemCaseSensitive(styling, "text_color");
        if (cJSON_IsString(tc)) SafeStringCopy(g_config.styling.text_color, sizeof(g_config.styling.text_color), tc->valuestring);
        
        cJSON* bbc = cJSON_GetObjectItemCaseSensitive(styling, "badge_bg_color");
        if (cJSON_IsString(bbc)) SafeStringCopy(g_config.styling.badge_bg_color, sizeof(g_config.styling.badge_bg_color), bbc->valuestring);
        cJSON* bbo = cJSON_GetObjectItemCaseSensitive(styling, "badge_bg_opacity");
        if (cJSON_IsNumber(bbo)) g_config.styling.badge_bg_opacity = (float)bbo->valuedouble;
    }

    // Default target display if omitted
    SafeStringCopy(g_config.behavior.target_display, sizeof(g_config.behavior.target_display), "all");

    // Parse Behavior
    cJSON* behavior = cJSON_GetObjectItemCaseSensitive(root, "behavior");
    if (behavior) {
        cJSON* ht = cJSON_GetObjectItemCaseSensitive(behavior, "hotkey_toggle");
        if (cJSON_IsString(ht)) SafeStringCopy(g_config.behavior.hotkey_toggle, sizeof(g_config.behavior.hotkey_toggle), ht->valuestring);
        cJSON* td = cJSON_GetObjectItemCaseSensitive(behavior, "target_display");
        if (cJSON_IsString(td) && td->valuestring) {
            SafeStringCopy(g_config.behavior.target_display, sizeof(g_config.behavior.target_display), td->valuestring);
        }
    }

    // Evaluate target_mode and target_index
    if (stricmp(g_config.behavior.target_display, "all") == 0 ||
        stricmp(g_config.behavior.target_display, "expand") == 0 ||
        stricmp(g_config.behavior.target_display, "multi") == 0) {
        g_config.behavior.target_mode = TARGET_DISPLAY_ALL;
        g_config.behavior.target_index = 0;
    } else if (stricmp(g_config.behavior.target_display, "primary") == 0 ||
               strlen(g_config.behavior.target_display) == 0) {
        g_config.behavior.target_mode = TARGET_DISPLAY_PRIMARY;
        g_config.behavior.target_index = 0;
    } else {
        int idx = atoi(g_config.behavior.target_display);
        if (idx > 0) {
            g_config.behavior.target_mode = TARGET_DISPLAY_INDEX;
            g_config.behavior.target_index = idx;
        } else {
            g_config.behavior.target_mode = TARGET_DISPLAY_ALL;
            g_config.behavior.target_index = 0;
        }
    }

    cJSON_Delete(root);
    return true;
}

// Watcher thread context
typedef struct {
    char filepath[MAX_PATH];
    char dirpath[MAX_PATH];
    HWND hwndNotify;
} WatcherContext;

static unsigned __stdcall ConfigWatcherThread(void* arg) {
    WatcherContext* ctx = (WatcherContext*)arg;
    
    HANDLE hDir = CreateFileA(
        ctx->dirpath,
        FILE_LIST_DIRECTORY,
        FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
        NULL,
        OPEN_EXISTING,
        FILE_FLAG_BACKUP_SEMANTICS,
        NULL
    );

    if (hDir == INVALID_HANDLE_VALUE) {
        free(ctx);
        return 1;
    }

    char buffer[1024];
    DWORD bytesReturned;
    
    // Extract filename from filepath
    const char* filename = strrchr(ctx->filepath, '\\');
    if (filename) filename++;
    else filename = ctx->filepath;

    while (true) {
        if (ReadDirectoryChangesW(
            hDir,
            buffer,
            sizeof(buffer),
            FALSE, // no subtree
            FILE_NOTIFY_CHANGE_LAST_WRITE | FILE_NOTIFY_CHANGE_FILE_NAME,
            &bytesReturned,
            NULL,
            NULL)) {
            
            FILE_NOTIFY_INFORMATION* fni = (FILE_NOTIFY_INFORMATION*)buffer;
            do {
                // Convert wide filename to utf8 for comparison
                char changedFile[MAX_PATH] = {0};
                WideCharToMultiByte(CP_UTF8, 0, fni->FileName, fni->FileNameLength / sizeof(WCHAR), changedFile, sizeof(changedFile) - 1, NULL, NULL);
                
                if (strcmp(changedFile, filename) == 0 && fni->Action == FILE_ACTION_MODIFIED) {
                    // Security Integrity: Move LoadConfig out of background thread to prevent Race Conditions 
                    // on the g_config global object. Just post the message and let the main thread load it.
                    if (ctx->hwndNotify) {
                        PostMessage(ctx->hwndNotify, WM_CONFIG_RELOADED, 0, 0);
                    }
                }
                
                if (fni->NextEntryOffset == 0) break;
                fni = (FILE_NOTIFY_INFORMATION*)((BYTE*)fni + fni->NextEntryOffset);
            } while (true);
        }
    }

    CloseHandle(hDir);
    free(ctx);
    return 0;
}

bool WatchConfigFile(const char* filepath, HWND hwndNotify) {
    WatcherContext* ctx = (WatcherContext*)malloc(sizeof(WatcherContext));
    if (!ctx) return false;
    
    SafeStringCopy(ctx->filepath, sizeof(ctx->filepath), filepath);
    ctx->hwndNotify = hwndNotify;
    
    // Extract directory
    SafeStringCopy(ctx->dirpath, sizeof(ctx->dirpath), filepath);
    char* lastSlash = strrchr(ctx->dirpath, '\\');
    if (lastSlash) {
        *lastSlash = '\0';
    } else {
        strcpy(ctx->dirpath, ".");
    }

    uintptr_t threadId = _beginthreadex(NULL, 0, ConfigWatcherThread, ctx, 0, NULL);
    if (threadId == 0) {
        free(ctx);
        return false;
    }
    
    // Systems Security: Close the thread handle immediately to prevent a resource leak.
    // The thread continues executing autonomously until process exit.
    CloseHandle((HANDLE)threadId);
    return true;
}
