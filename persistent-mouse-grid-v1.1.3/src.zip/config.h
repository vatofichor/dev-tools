/*
# Copyright (c) 2026:
# vatofichor - Sebastian Mass     [>_<]
# & Assisted By Gemini Antigravity /|\
*/

#ifndef CONFIG_H
#define CONFIG_H

#include <windows.h>
#include <stdbool.h>

#define WM_CONFIG_RELOADED (WM_USER + 1)

typedef struct {
    int primary_rows;
    int primary_cols;
    int subgrid_rows;
    int subgrid_cols;
} GridConfig;

typedef struct {
    char primary_line_color[10];
    float primary_line_opacity;
    int primary_line_thickness;
    char subgrid_line_color[10];
    float subgrid_line_opacity;
    int subgrid_line_thickness;
    char font_family[64];
    int font_size;
    char text_color[10];
    char badge_bg_color[10];
    float badge_bg_opacity;
} StylingConfig;

typedef enum {
    TARGET_DISPLAY_PRIMARY = 0,
    TARGET_DISPLAY_ALL = 1,
    TARGET_DISPLAY_INDEX = 2
} TargetDisplayMode;

typedef struct {
    char hotkey_toggle[32];
    char target_display[32];
    TargetDisplayMode target_mode;
    int target_index;
} BehaviorConfig;

typedef struct {
    GridConfig grid;
    StylingConfig styling;
    BehaviorConfig behavior;
} AppConfig;

// Global config instance
extern AppConfig g_config;

// Parses grid_config.json into g_config
bool LoadConfig(const char* filepath);

// Sets up a directory watcher for the config file to reload automatically
bool WatchConfigFile(const char* filepath, HWND hwndNotify);

#endif // CONFIG_H
