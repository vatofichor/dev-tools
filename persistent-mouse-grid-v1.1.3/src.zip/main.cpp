/*
# Copyright (c) 2026:
# vatofichor - Sebastian Mass     [>_<]
# & Assisted By Gemini Antigravity /|\
*/

#include <windows.h>
#include <gdiplus.h>
#include <stdio.h>
#include <vector>
#include "config.h"

#pragma comment(lib, "gdiplus.lib")
#pragma comment(lib, "user32.lib")
#pragma comment(lib, "gdi32.lib")

using namespace Gdiplus;

struct GridWindow {
    HWND hwnd;
    HMONITOR hMonitor;
    RECT rcMonitor;
    int width;
    int height;
    int monitorIndex;
};

// Globals
HINSTANCE g_hInstance = NULL;
HWND g_hTrayWnd = NULL;
std::vector<GridWindow> g_gridWindows;
ULONG_PTR g_gdiplusToken;

#define WM_TRAYICON (WM_USER + 2)
#define ID_TRAY_TOGGLE 1001
#define ID_TRAY_RELOAD 1002
#define ID_TRAY_EXIT 1003
#define HOTKEY_ID 1

bool g_gridVisible = true;
NOTIFYICONDATA nid = {0};

void InitTrayIcon(HWND hwnd) {
    nid.cbSize = sizeof(NOTIFYICONDATA);
    nid.hWnd = hwnd;
    nid.uID = 1;
    nid.uFlags = NIF_ICON | NIF_MESSAGE | NIF_TIP;
    nid.uCallbackMessage = WM_TRAYICON;
    nid.hIcon = LoadIcon(NULL, IDI_APPLICATION); // Default icon
    strcpy(nid.szTip, "Persistent Mouse Grid");
    Shell_NotifyIcon(NIM_ADD, &nid);
}

void RemoveTrayIcon() {
    Shell_NotifyIcon(NIM_DELETE, &nid);
}

void RegisterConfigHotkey(HWND hwnd) {
    UnregisterHotKey(hwnd, HOTKEY_ID);

    UINT modifiers = 0;
    UINT vk = 0;
    
    char hk[32];
    strncpy(hk, g_config.behavior.hotkey_toggle, sizeof(hk));
    hk[31] = '\0';
    
    for (int i = 0; hk[i]; i++) hk[i] = toupper(hk[i]);

    if (strstr(hk, "CTRL")) modifiers |= MOD_CONTROL;
    if (strstr(hk, "SHIFT")) modifiers |= MOD_SHIFT;
    if (strstr(hk, "ALT")) modifiers |= MOD_ALT;
    if (strstr(hk, "WIN")) modifiers |= MOD_WIN;

    char* lastPlus = strrchr(hk, '+');
    if (lastPlus && *(lastPlus + 1) != '\0') {
        char keyChar = *(lastPlus + 1);
        vk = VkKeyScan(keyChar) & 0xFF;
    } else if (strlen(hk) == 1) {
        vk = VkKeyScan(hk[0]) & 0xFF;
    }

    if (vk == 0) vk = 'G'; // Fallback

    RegisterHotKey(hwnd, HOTKEY_ID, modifiers | MOD_NOREPEAT, vk);
}

// Forward decl
void DrawGrid(const GridWindow& win);

void ToggleAllGrids() {
    g_gridVisible = !g_gridVisible;
    for (const auto& win : g_gridWindows) {
        if (g_gridVisible) {
            ShowWindow(win.hwnd, SW_SHOWNOACTIVATE);
            DrawGrid(win);
        } else {
            ShowWindow(win.hwnd, SW_HIDE);
        }
    }
}

// Helper to parse hex colors
static Color ParseColor(const char* hex, float opacity) {
    if (!hex) return Color((BYTE)(opacity * 255), 255, 255, 255);
    if (hex[0] == '#') hex++;
    int r = 255, g = 255, b = 255;
    sscanf(hex, "%02x%02x%02x", &r, &g, &b);
    return Color((BYTE)(opacity * 255), r, g, b);
}

void DrawGrid(const GridWindow& win) {
    int width = win.width;
    int height = win.height;

    if (width <= 0 || height <= 0) return;

    HDC hdcScreen = GetDC(0);
    HDC hdcMem = CreateCompatibleDC(hdcScreen);
    
    BITMAPINFO bmi = {0};
    bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bmi.bmiHeader.biWidth = width;
    bmi.bmiHeader.biHeight = -height; // Top-down
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biCompression = BI_RGB;

    void* pBits = NULL;
    HBITMAP hBitmap = CreateDIBSection(hdcMem, &bmi, DIB_RGB_COLORS, &pBits, NULL, 0);
    HBITMAP hOldBitmap = (HBITMAP)SelectObject(hdcMem, hBitmap);

    // GDI+ drawing scope
    {
        Graphics graphics(hdcMem);
        graphics.SetSmoothingMode(SmoothingModeAntiAlias);
        graphics.SetTextRenderingHint(TextRenderingHintAntiAlias);
        graphics.Clear(Color(0, 0, 0, 0)); // Fully transparent background

        Color primColor = ParseColor(g_config.styling.primary_line_color, g_config.styling.primary_line_opacity);
        Color subColor = ParseColor(g_config.styling.subgrid_line_color, g_config.styling.subgrid_line_opacity);
        
        Pen primPen(primColor, (REAL)g_config.styling.primary_line_thickness);
        Pen subPen(subColor, (REAL)g_config.styling.subgrid_line_thickness);

        float cellW = (float)width / (g_config.grid.primary_cols > 0 ? g_config.grid.primary_cols : 3);
        float cellH = (float)height / (g_config.grid.primary_rows > 0 ? g_config.grid.primary_rows : 3);

        // Render nested subgrid
        int sCols = g_config.grid.subgrid_cols > 0 ? g_config.grid.subgrid_cols : 3;
        int sRows = g_config.grid.subgrid_rows > 0 ? g_config.grid.subgrid_rows : 3;

        for (int r = 0; r < g_config.grid.primary_rows; r++) {
            for (int c = 0; c < g_config.grid.primary_cols; c++) {
                float x0 = c * cellW;
                float y0 = r * cellH;
                float subW = cellW / sCols;
                float subH = cellH / sRows;
                
                for (int i = 1; i < sCols; i++) {
                    graphics.DrawLine(&subPen, x0 + i * subW, y0, x0 + i * subW, y0 + cellH);
                }
                for (int i = 1; i < sRows; i++) {
                    graphics.DrawLine(&subPen, x0, y0 + i * subH, x0 + cellW, y0 + i * subH);
                }
            }
        }

        // Render primary grid
        for (int i = 1; i < g_config.grid.primary_cols; i++) {
            graphics.DrawLine(&primPen, i * cellW, 0.0f, i * cellW, (float)height);
        }
        for (int i = 1; i < g_config.grid.primary_rows; i++) {
            graphics.DrawLine(&primPen, 0.0f, i * cellH, (float)width, i * cellH);
        }

        // Render text badges
        WCHAR wFontFamily[64] = L"Segoe UI";
        if (g_config.styling.font_family[0]) {
            MultiByteToWideChar(CP_UTF8, 0, g_config.styling.font_family, -1, wFontFamily, 64);
        }
        FontFamily fontFamily(wFontFamily);
        int fontSize = g_config.styling.font_size > 0 ? g_config.styling.font_size : 14;
        Font font(&fontFamily, (REAL)fontSize, FontStyleBold, UnitPixel);
        
        int subFontSize = (int)(fontSize * 0.7f);
        if (subFontSize < 8) subFontSize = 8;
        Font subFont(&fontFamily, (REAL)subFontSize, FontStyleRegular, UnitPixel);

        Color textColor = ParseColor(g_config.styling.text_color, 1.0f);
        Color badgeColor = ParseColor(g_config.styling.badge_bg_color, g_config.styling.badge_bg_opacity);
        SolidBrush textBrush(textColor);
        SolidBrush badgeBrush(badgeColor);

        StringFormat format;
        format.SetAlignment(StringAlignmentCenter);
        format.SetLineAlignment(StringAlignmentCenter);

        int counter = 1;
        for (int r = 0; r < g_config.grid.primary_rows; r++) {
            for (int c = 0; c < g_config.grid.primary_cols; c++) {
                float cx = c * cellW + cellW / 2.0f;
                float cy = r * cellH + cellH / 2.0f;
                
                // Draw subgrid labels
                int subCounter = 1;
                for (int sr = 0; sr < sRows; sr++) {
                    for (int sc = 0; sc < sCols; sc++) {
                        float subW = cellW / sCols;
                        float subH = cellH / sRows;
                        float subCx = (c * cellW) + (sc * subW) + subW / 2.0f;
                        float subCy = (r * cellH) + (sr * subH) + subH / 2.0f;

                        // Center index
                        int centerSr = sRows / 2;
                        int centerSc = sCols / 2;
                        if (sr == centerSr && sc == centerSc) {
                            subCounter++;
                            continue;
                        }

                        WCHAR subText[16];
                        swprintf(subText, 16, L"%d", subCounter++);

                        RectF subTextRect;
                        graphics.MeasureString(subText, -1, &subFont, PointF(subCx, subCy), &format, &subTextRect);

                        float subPad = 4.0f;
                        RectF subBadgeRect(subCx - subTextRect.Width / 2.0f - subPad, subCy - subTextRect.Height / 2.0f - subPad, subTextRect.Width + subPad * 2, subTextRect.Height + subPad * 2);

                        graphics.FillRectangle(&badgeBrush, subBadgeRect);
                        graphics.DrawString(subText, -1, &subFont, PointF(subCx, subCy), &format, &textBrush);
                    }
                }
                
                // Draw primary cell label
                WCHAR text[16];
                swprintf(text, 16, L"%d", counter++);
                
                RectF textRect;
                graphics.MeasureString(text, -1, &font, PointF(cx, cy), &format, &textRect);
                
                float pad = 6.0f;
                RectF badgeRect(cx - textRect.Width / 2.0f - pad, cy - textRect.Height / 2.0f - pad, textRect.Width + pad * 2, textRect.Height + pad * 2);
                
                graphics.FillRectangle(&badgeBrush, badgeRect);
                graphics.DrawString(text, -1, &font, PointF(cx, cy), &format, &textBrush);
            }
        }
    }

    // Per-pixel alpha blend update positioned on specific monitor coordinates
    POINT ptDst = { win.rcMonitor.left, win.rcMonitor.top };
    POINT ptSrc = {0, 0};
    SIZE size = {width, height};
    BLENDFUNCTION blend = {0};
    blend.BlendOp = AC_SRC_OVER;
    blend.BlendFlags = 0;
    blend.SourceConstantAlpha = 255;
    blend.AlphaFormat = AC_SRC_ALPHA;

    UpdateLayeredWindow(win.hwnd, hdcScreen, &ptDst, &size, hdcMem, &ptSrc, 0, &blend, ULW_ALPHA);

    SelectObject(hdcMem, hOldBitmap);
    DeleteObject(hBitmap);
    DeleteDC(hdcMem);
    ReleaseDC(0, hdcScreen);
}

struct EnumContext {
    int index;
};

BOOL CALLBACK MonitorEnumProc(HMONITOR hMonitor, HDC hdcMonitor, LPRECT lprcMonitor, LPARAM dwData) {
    EnumContext* ctx = (EnumContext*)dwData;
    ctx->index++;

    MONITORINFOEX mi;
    mi.cbSize = sizeof(MONITORINFOEX);
    if (!GetMonitorInfo(hMonitor, &mi)) return TRUE;

    bool createThisWindow = false;
    if (g_config.behavior.target_mode == TARGET_DISPLAY_ALL) {
        createThisWindow = true;
    } else if (g_config.behavior.target_mode == TARGET_DISPLAY_PRIMARY) {
        if (mi.dwFlags & MONITORINFOF_PRIMARY) createThisWindow = true;
    } else if (g_config.behavior.target_mode == TARGET_DISPLAY_INDEX) {
        if (ctx->index == g_config.behavior.target_index) createThisWindow = true;
    }

    if (!createThisWindow) return TRUE;

    const char* CLASS_NAME = "PersistentMouseGridClass";

    int x = mi.rcMonitor.left;
    int y = mi.rcMonitor.top;
    int w = mi.rcMonitor.right - mi.rcMonitor.left;
    int h = mi.rcMonitor.bottom - mi.rcMonitor.top;

    HWND hwnd = CreateWindowEx(
        WS_EX_TOPMOST | WS_EX_TRANSPARENT | WS_EX_LAYERED | WS_EX_NOACTIVATE | WS_EX_TOOLWINDOW,
        CLASS_NAME,
        "Persistent Mouse Grid",
        WS_POPUP,
        x, y, w, h,
        NULL, NULL, g_hInstance, NULL
    );

    if (hwnd) {
        SetWindowPos(hwnd, HWND_TOPMOST, x, y, w, h, SWP_NOACTIVATE | (g_gridVisible ? SW_SHOW : SW_HIDE));
        GridWindow gw;
        gw.hwnd = hwnd;
        gw.hMonitor = hMonitor;
        gw.rcMonitor = mi.rcMonitor;
        gw.width = w;
        gw.height = h;
        gw.monitorIndex = ctx->index;
        g_gridWindows.push_back(gw);

        if (g_gridVisible) DrawGrid(gw);
    }

    return TRUE;
}

void DestroyAllGridWindows() {
    for (const auto& win : g_gridWindows) {
        if (win.hwnd) DestroyWindow(win.hwnd);
    }
    g_gridWindows.clear();
}

void RebuildGridWindows() {
    DestroyAllGridWindows();
    EnumContext ctx = { 0 };
    EnumDisplayMonitors(NULL, NULL, MonitorEnumProc, (LPARAM)&ctx);
}

LRESULT CALLBACK TrayWndProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
    switch (uMsg) {
        case WM_CREATE: {
            LoadConfig("grid_config.json");
            WatchConfigFile("grid_config.json", hwnd);
            InitTrayIcon(hwnd);
            RegisterConfigHotkey(hwnd);
            RebuildGridWindows();
            return 0;
        }

        case WM_CONFIG_RELOADED: {
            Sleep(50);
            LoadConfig("grid_config.json");
            RegisterConfigHotkey(hwnd);
            RebuildGridWindows();
            return 0;
        }

        case WM_DISPLAYCHANGE: {
            RebuildGridWindows();
            return 0;
        }

        case WM_TRAYICON: {
            if (lParam == WM_RBUTTONUP || lParam == WM_LBUTTONUP) {
                POINT pt;
                GetCursorPos(&pt);
                HMENU hMenu = CreatePopupMenu();
                InsertMenu(hMenu, -1, MF_BYPOSITION | MF_STRING, ID_TRAY_TOGGLE, g_gridVisible ? "Hide Grid" : "Show Grid");
                InsertMenu(hMenu, -1, MF_BYPOSITION | MF_STRING, ID_TRAY_RELOAD, "Reload Config");
                InsertMenu(hMenu, -1, MF_BYPOSITION | MF_SEPARATOR, 0, NULL);
                InsertMenu(hMenu, -1, MF_BYPOSITION | MF_STRING, ID_TRAY_EXIT, "Exit");

                SetForegroundWindow(hwnd);
                TrackPopupMenu(hMenu, TPM_BOTTOMALIGN | TPM_LEFTALIGN, pt.x, pt.y, 0, hwnd, NULL);
                DestroyMenu(hMenu);
            }
            return 0;
        }

        case WM_COMMAND: {
            int wmId = LOWORD(wParam);
            switch (wmId) {
                case ID_TRAY_TOGGLE:
                    ToggleAllGrids();
                    break;
                case ID_TRAY_RELOAD:
                    LoadConfig("grid_config.json");
                    RegisterConfigHotkey(hwnd);
                    RebuildGridWindows();
                    break;
                case ID_TRAY_EXIT:
                    DestroyWindow(hwnd);
                    break;
            }
            return 0;
        }

        case WM_HOTKEY: {
            if (wParam == HOTKEY_ID) {
                ToggleAllGrids();
            }
            return 0;
        }

        case WM_DESTROY: {
            RemoveTrayIcon();
            DestroyAllGridWindows();
            PostQuitMessage(0);
            return 0;
        }
    }
    return DefWindowProc(hwnd, uMsg, wParam, lParam);
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR pCmdLine, int nCmdShow) {
    g_hInstance = hInstance;

    GdiplusStartupInput gdiplusStartupInput;
    GdiplusStartup(&g_gdiplusToken, &gdiplusStartupInput, NULL);

    const char* GRID_CLASS_NAME = "PersistentMouseGridClass";
    const char* TRAY_CLASS_NAME = "PersistentMouseGridTrayClass";

    // Register Grid Window Class
    WNDCLASS wcGrid = { 0 };
    wcGrid.lpfnWndProc = DefWindowProc; // Grid windows don't process direct window messages
    wcGrid.hInstance = hInstance;
    wcGrid.lpszClassName = GRID_CLASS_NAME;
    wcGrid.hCursor = LoadCursor(NULL, IDC_ARROW);

    if (!RegisterClass(&wcGrid)) {
        MessageBox(NULL, "Grid Window Registration Failed!", "Error", MB_ICONEXCLAMATION | MB_OK);
        GdiplusShutdown(g_gdiplusToken);
        return 0;
    }

    // Register Tray Controller Window Class
    WNDCLASS wcTray = { 0 };
    wcTray.lpfnWndProc = TrayWndProc;
    wcTray.hInstance = hInstance;
    wcTray.lpszClassName = TRAY_CLASS_NAME;

    if (!RegisterClass(&wcTray)) {
        MessageBox(NULL, "Tray Controller Registration Failed!", "Error", MB_ICONEXCLAMATION | MB_OK);
        GdiplusShutdown(g_gdiplusToken);
        return 0;
    }

    // Create hidden background Tray Controller Window
    g_hTrayWnd = CreateWindowEx(
        0, TRAY_CLASS_NAME, "MouseGridTrayController", 0,
        0, 0, 0, 0, HWND_MESSAGE, NULL, hInstance, NULL
    );

    if (g_hTrayWnd == NULL) {
        MessageBox(NULL, "Tray Controller Creation Failed!", "Error", MB_ICONEXCLAMATION | MB_OK);
        GdiplusShutdown(g_gdiplusToken);
        return 0;
    }

    MSG msg = { 0 };
    while (GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    GdiplusShutdown(g_gdiplusToken);
    return 0;
}
